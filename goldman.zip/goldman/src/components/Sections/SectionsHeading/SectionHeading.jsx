import React from 'react'

const SectionHeading = () => {
  return (
    <div className='flex flex-wrap justify-around'>
        <div>
        </div>
        <p>Heading</p>
    </div>
  )
}

export default SectionHeading 