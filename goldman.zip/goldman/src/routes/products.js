import { data } from "react-router-dom";
import content from "../data/content.json"

export const loadProductById = async ({params}) =>{
    const product = content?.product?.find((product)=> product?.id?.toString() === params?.productId?.toString());
    return {product};
}