import { Breadcrumbs, Button, Rating } from "@mui/material";
import React, { useEffect, useMemo, useState } from "react";
import { useLoaderData } from "react-router-dom";
import Category from "../../components/Sections/Categories/Category";
import SizeFilter from "../../components/Filters/SizeFilter";
import ProductCard from "../ProductListPage/ProductCard";

const categories = content?.categories;

const extraSections = [
  {
    icon: <SvgCreditCard />,
    label: 'Secure payment'
  },
  {
    icon: <SvgCloth />,
    label: 'Size & Fit'
  },
  {
    icon: <SvgShipping />,
    label: 'Free shipping'
  },
  {
    icon: <SvgReturn />,
    label: 'Free shipping & Returns'
  },
]


const ProductDetails = () => {
  const { product } = useLoaderData();
  const [image, setImage] = useState(product?.image[0]?.startwith('http') ? product?.image[0] : product?.thumbnail);
  const [breadCrumbLinks, setBreadCrumbLink] = useState([]);

  const similarProducts = useMemo(() => {
    return content?.products?.fliter((item) => item?.type_id === product?.type_id)
  }, [product]);

  const productCategory = useMemo(() => {
    return categories?.find((category) => category?.id === product?.category_id)
  }, [product])

  useEffect(() => {
    setBreadCrumbLink([]);
    const arrayLinks = [{ title: 'shop', path: '/' }, {
      title: productCategory?.name,
      path: productCategory?.path
    }];
    const productType = productCategory?.types?.find((item) => item?.type_id === product?.type_id);
    console.log("product type ", productType, productCategory);
    if (productType) {
      arrayLinks?.push({
        title: productType?.name,
        path: productType?.name
      })
    }
    setBreadCrumbLink(arrayLinks);
  }, [productCategory.product])

  return (
    <div className='flex flex-col md:flex-row px-10' >
      <div className='w-[100%] lg:w[50%] md:w-[40%]'>
        {/* image */}
        <div className='flex flex-col md:flex-row'>
          <div className='w-[100%] md:w-[20%] justify-center h-[40px] md:h-[420px]'>
            {/* stack images */}
            <div className='flex flex-row md:flex-col justify-center h-full'>
              {
                product?.image[0]?.startwith('http') && product?.image?.map(item, index) => (
              <button onClick={() => setImage(item)} className='rounded-lg w-fit p-2 mb-2'>
                <img src={item} className='h-[60px] w-[60px] rounded-lg bg-cover bg-center hover:scale-105 hover-border'
                  alt={'sample-' + index} />
              </button>
              ))
              }
            </div>

          </div>
          <div className='w-full md:w-[80%] flex justfy-center md:pt-0 pt-10'>
            <img src={image} className='h-full w-full max-h-[520px] border rounded lg cursor printer object-cover'
              alt={product?.title} />
          </div>
        </div>
//나 : 잘못 작성
      {/* </div>
      <div className='w-[60%] px-10'>
        { Product Description }
        <Breadcrumb links={breadCrumbLinks} />  
        <p className='text-3xl pt-4'>{product?.name}</p>
        <Rating rating={product?.rating} />
        { Price Tag }
        <p className='text-xl bold py-2'>${product?.price}</p>
        <div className='flex flex-col'>
          <div className='flex gap-2'>
            <p className= 'text-sm bold'>Select Size</p>
            <Link className='text-sm text-gray-500 hover:text-gray-900' to={'https://en.wikipedia.org/wiki/clothing_sizes'}></Link>
          </div>
        </div>
        <div className='mt-2'><SizeFilter sizes={product?.size} hidleTitle/></div>  
        <div>
          <p className='text-lg bold'>Colors Available</p>
          <ProductColors colors={product?.color}/>
        </div> 
        <div className='flex pt-4'>
          <button className='bg-black border rounded-lg w-[155px] px-2'><div className='flex items-center rounded-lg bg-'></div></button>
        </div>     
      </div>
    </div> */}

    
//AI 추천
</div>
{/*Product Description */}
<SeactionHeading title={'Similar Products'}/>
<div className='flex px-10'>
<div className='pt-4 grid grid-cols-1 lg:grid-cols-4 md:grid-cols-3 gap-8 px-2 pb-10'>
        {similarProducts?.map((item,index)=>(
          <ProductCard key={index} {...item}/>
        ))}
        {!similarProducts?.length && <p>No Product Found!</p>}
</div>
</div>
</>
)
}



export default ProductDetails